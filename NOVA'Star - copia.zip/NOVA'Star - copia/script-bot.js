const chatInput = document.querySelector(".chat-input textarea");
const sendChat = document.querySelector(".chat-input span");
const chatbox = document.querySelector(".chatbox")
const chatbotToggler = document.querySelector(.chatbox-toggler");

let userMessage;
const API_KEY = "sk-proj-fqsMWWaJHUkvupFFTxk-44XOmavoeVChO0WjHi2pfve544tjqE76PMruTSgREzCjNvk6_h9t3BlbkFJTqkiKY9wQD4NZo6S7IBz3zovmjF3HLLYXIN0RL2kyjC4C97jNvhJITM66SDTQzrCU1VQhiaYUA";

const createChatLi = (message, className) => {
    //Create  a chat <li> element with passed message and className
    const chatLi = document.createElement("li");
    chatLi.classList.add("chat", className);
    let chatContent = className === "outgoing" ? `<p></p>` : `<span class="material-symbols-outlined">smart_toy</span><p></p>`;
    chatLi.innerHTML = chatContent;
    chatLi.querySelector("p").textContent = message;
    return chatLi;
}

const  generateResponse = (incomingChatLi) => {
    const API_URL = "https://api.openai.com/v1/chat/completions";
    const requestOptions = incomingChatLi.querySelector("p");


    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${API_KEY}`
        },
        body: JSON.stringify({
            model:"gpt-3.5-turbo"
            message: [{role: "user, content: usserMessage"}]
        })
    }

    // Send POST request to API, get response
    fetch(API_URL, requestOptions).then(res => res.json()).then(data => {
        messageElement.textContent = data.choices[0].message.content;
    }).catch((error) => {
        messageElement.textContent = "Oops! Something went wrong. Please try again.";
    }).finally(() => chatbox.scrollTo(0, chatbox.scrollHeight));
}

const handleChat = () => {
    userMessage = chatInput.value.trim();
    if(!userMessage) return;
    chatInput.value = "";
    //Append the user's message to the chatbox
    chatbox.appendChild(createChatLi(userMessage, "outgoing"));
    chatbox.scroll(0, chatbox.scrollHeight);

    setTimeout(() => {
        //Display "Thingking..." message ehile waiting for the response
        const incomingChatLi = createChatLi("Thinking...", "incoming")
        chatbox.appendChild();
        chatbox.scroll(0, chatbox.scrollHeight);
        generateResponse(incomingChatLi);
    }, 600);

}

chatbotToggler.addEventListener("click", () => document.body.classList.toggle("show-chatbot"));
sendChatBtn.addEventListener("click, handleChat");