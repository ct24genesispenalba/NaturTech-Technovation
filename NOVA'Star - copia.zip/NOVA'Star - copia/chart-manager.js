let humedadChart, fotoresistenciaChart;

// Función para crear los gráficos
function createCharts(data) {
    console.log('Creando gráficos con datos:', data);

    const commonOptions = {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        },
        animation: false,
        elements: {
            line: {
                tension: 0.3
            }
        }
    };

    try {
        // Crear gráfico de humedad (Field 1)
        const ctxHum = document.getElementById('humedadChart');
        if (!ctxHum) {
            throw new Error('No se encontró el elemento humedadChart');
        }
        humedadChart = new Chart(ctxHum, {
            type: 'line',
            data: {
                labels: data.map(feed => new Date(feed.created_at).toLocaleTimeString()), // Etiquetas del eje X (hora)
                datasets: [{
                    label: 'Humedad (%)',
                    data: data.map(feed => feed.field1), // Datos de humedad (Field 1)
                    borderColor: 'rgb(54, 162, 235)',
                    backgroundColor: 'rgba(54, 162, 235, 0.1)',
                    fill: true
                }]
            },
            options: commonOptions
        });

        // Crear gráfico de fotoresistencia (Field 2)
        const ctxFoto = document.getElementById('fotoresistenciaChart');
        if (!ctxFoto) {
            throw new Error('No se encontró el elemento fotoresistenciaChart');
        }
        fotoresistenciaChart = new Chart(ctxFoto, {
            type: 'line',
            data: {
                labels: data.map(feed => new Date(feed.created_at).toLocaleTimeString()), // Etiquetas del eje X (hora)
                datasets: [{
                    label: 'Fotoresistencia (Luz)',
                    data: data.map(feed => feed.field2), // Datos de fotoresistencia (Field 2)
                    borderColor: 'rgb(255, 159, 64)',
                    backgroundColor: 'rgba(255, 159, 64, 0.1)',
                    fill: true
                }]
            },
            options: commonOptions
        });

        console.log('Gráficos creados exitosamente');
    } catch (error) {
        console.error('Error al crear los gráficos:', error);
        document.getElementById('error-message').textContent = 
            `Error al crear los gráficos: ${error.message}`;
    }
}

// Función para actualizar los gráficos con nuevos datos
function updateCharts(data) {
    console.log('Actualizando gráficos con nuevos datos:', data);

    try {
        if (!humedadChart || !fotoresistenciaChart) {
            console.log('Los gráficos no existen, creándolos...');
            createCharts(data); // Crear los gráficos si aún no existen
        } else {
            const timeLabels = data.map(feed => new Date(feed.created_at).toLocaleTimeString());

            // Actualizar gráfico de humedad
            humedadChart.data.labels = timeLabels;
            humedadChart.data.datasets[0].data = data.map(feed => feed.field1);
            humedadChart.update();

            // Actualizar gráfico de fotoresistencia
            fotoresistenciaChart.data.labels = timeLabels;
            fotoresistenciaChart.data.datasets[0].data = data.map(feed => feed.field2);
            fotoresistenciaChart.update();

            console.log('Gráficos actualizados exitosamente');
        }
    } catch (error) {
        console.error('Error al actualizar los gráficos:', error);
        document.getElementById('error-message').textContent = 
            `Error al actualizar los gráficos: ${error.message}`;
    }
}

// Función para obtener datos de ThingSpeak y actualizar los gráficos
async function fetchAndUpdateCharts() {
    try {
        console.log('Obteniendo datos de ThingSpeak...');
        const channelId = '2822780'; // ID del canal de ThingSpeak
        const url = `https://api.thingspeak.com/channels/${channelId}/feeds.json?results=60`;

        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Error HTTP! Estado: ${response.status}`);
        }
        const data = await response.json();

        if (!data.feeds || data.feeds.length === 0) {
            throw new Error('No se recibieron datos de ThingSpeak');
        }

        // Llamar a la función para actualizar los gráficos con los nuevos datos
        updateCharts(data.feeds);
    } catch (error) {
        console.error('Error al obtener o actualizar los gráficos:', error);
        document.getElementById('error-message').textContent = 
            `Error: ${error.message}. Por favor, revisa la consola para más detalles.`;
    }
}

// Llamada inicial para cargar los gráficos con los datos de ThingSpeak
fetchAndUpdateCharts();