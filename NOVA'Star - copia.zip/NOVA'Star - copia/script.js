const btnSingIn = document.getElementById("btn-sing-in");
const btnSingUp = document.getElementById("btn-sing-up");
const container = document.querySelector(".container");

btnSingIn.addEventListener("click", () =>
{
    container.classList.remove("toggle");
});

btnSingUp.addEventListener("click", () =>
{
    container.classList.add("toggle");
});