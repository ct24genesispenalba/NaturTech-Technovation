import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.2.0/firebase-auth.js";


// Your web app’s Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDHdobBAzJ6LylQ4Yyrql-Xn6dut4fn-o",
    authDomain: "nova-ec45e.firebaseapp.com",
    projectId: "nova-ec45e",
    storageBucket: "nova-ec45e.firebasestorage.app",
    messagingSenderId: "79111912643",
    appId: "1:79111912643:web:c0603ba5ef5e512a6a3676"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// submit button
const submit = document.getElementById('submit');
submit.addEventListener("click", function (event) {
    event.preventDefault();

    //inputs
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
    //Signed up
    const user = userCredential.user;
    alert("Creating Account...")
    window.location.href = "NOVAID8.html";
    // ...
    })
    .catch((error) => {
    const errorCode = error.code;
    const errorMessage = error.message;
    alert(error.message)
    // ..
    });
});